/**
 * Shared TypeScript types for the Hermes Memory extension.
 */

import type { ModelThinkingLevel, TextContent } from "@earendil-works/pi-ai";

export type MemoryOverflowStrategy = "auto-consolidate" | "reject" | "fifo-evict";

export type SessionSearchVariant = "legacy" | "anchors";

export type ThinkingLevel = ModelThinkingLevel;

export type ReviewTransport = "direct" | "subprocess";

export interface SessionSearchConfig {
  /** Session search implementation variant. Default: legacy */
  variant: SessionSearchVariant;
}

export interface MemoryConfig {
  /** Defer policy-only memory initialization until first use. Default: false */
  lazyInitialization?: boolean;
  /** Prompt memory mode. Default: policy-only */
  memoryMode: "policy-only" | "legacy-inject";
  /** Policy prompt style used when memoryMode is policy-only. Default: full */
  memoryPolicyStyle?: "full" | "compact" | "custom" | "none";
  /** Custom policy prompt text used when memoryPolicyStyle is custom */
  memoryPolicyCustomText?: string;
  /** Max chars for MEMORY.md (agent notes). Default: 5000 */
  memoryCharLimit: number;
  /** Max chars for USER.md (user profile). Default: 5000 */
  userCharLimit: number;
  /** Max chars for project-level MEMORY.md. Default: 5000 */
  projectCharLimit: number;
  /** Turns between background auto-reviews. Default: 10 */
  nudgeInterval: number;
  /** Recent conversation messages included in background review. 0 = all. Default: 0 */
  reviewRecentMessages?: number;
  /** Enable background learning loop. Default: true */
  reviewEnabled: boolean;
  /** How background review invokes the LLM. Default: direct */
  reviewTransport?: ReviewTransport;
  /** Flush memories before compaction. Default: true */
  flushOnCompact: boolean;
  /** Flush memories on session shutdown. Default: true */
  flushOnShutdown: boolean;
  /** Minimum user turns before flush triggers. Default: 6 */
  flushMinTurns: number;
  /** Recent conversation messages included in session flush. 0 = all. Default: 0 */
  flushRecentMessages?: number;
  /** Ceiling for the compact-path flush (direct + subprocess). Default: 60000 */
  flushCompactTimeoutMs?: number;

  /** Override extension storage directory. Default: ~/.pi/agent/pi-hermes-memory */
  memoryDir?: string;
  /** Directory for project-scoped memory (relative to ~/.pi/agent). Default: "projects-memory" */
  projectsMemoryDir?: string;
  /** Session search configuration. Default: { variant: "legacy" } */
  sessionSearch?: SessionSearchConfig;
  /** Run a full SQLite quick_check asynchronously after opening. Default: true */
  quickCheckOnOpen?: boolean;
  /** Override model used for child pi -p subprocess LLM calls. Default: unset */
  llmModelOverride?: string;
  /** Fallback model chain tried in order when the primary review model fails (rate limit, 401/403, 404, 500/503, invalid response). Default: unset */
  llmFallbackModels?: string[];
  /** Override thinking level used for child pi -p subprocess LLM calls. Default: unset */
  llmThinkingOverride?: ThinkingLevel;
  /** Trusted Pi extension sources required by child processes, such as custom providers or auth adapters. */
  childExtensionPaths?: string[];
  /** Strategy when memory is full. Default: auto-consolidate */
  memoryOverflowStrategy?: MemoryOverflowStrategy;
  /** Wall-clock grace after overflow before automatic consolidation. Default: 180000 */
  overflowGraceMs?: number;
  /** Legacy alias for memoryOverflowStrategy. Default: true */
  autoConsolidate: boolean;
  /** Detect user corrections and trigger immediate memory save. Default: true */
  correctionDetection: boolean;
  /** Override strong correction regex sources. Missing = defaults; [] = none. */
  correctionStrongPatterns?: string[];
  /** Override weak correction regex sources. Missing = defaults; [] = none. */
  correctionWeakPatterns?: string[];
  /** Override negative correction regex sources. Missing = defaults; [] = none. */
  correctionNegativePatterns?: string[];
  /** Override directive words used after weak correction patterns. Missing = defaults; [] = none. */
  correctionDirectiveWords?: string[];
  /** Inject recent failure memories into the system prompt. Default: true */
  failureInjectionEnabled: boolean;
  /** Maximum age in days for injected failure memories. Default: 7 */
  failureInjectionMaxAgeDays: number;
  /** Maximum number of failure memories to inject. Default: 5 */
  failureInjectionMaxEntries: number;
  /** Tool calls before triggering background review (in addition to turn count). Default: 15 */
  nudgeToolCalls: number;
  /** Maximum time in milliseconds for a consolidation run, auto or manual. Default: 180000 */
  consolidationTimeoutMs: number;
  /**
   * Master switch for chunked subprocess consolidation. When false (the
   * default), the subprocess path keeps the legacy single-shot behavior for
   * stores of any size. When true, entries joined above
   * `consolidationChunkChars` split the work into multiple child runs that
   * share one overall time budget (consolidationTimeoutMs); the loop stops at
   * the target's capacity goal. Has no effect on the direct (in-process)
   * transport.
   */
  /**
   * Enables chunked subprocess consolidation (bounded rounds with a shared
   * time budget). Default: false — the legacy single-shot behavior applies
   * until explicitly enabled. Provisional pending reproduction of the
   * original timeout on a faster model.
   */
  consolidationChunking?: boolean;
  consolidationChunkChars?: number;
  /**
   * Record memory_search recalls per entry (hit_count / last_hit_at). Default:
   * true. Recording is invisible — it changes no prompt, ranking, or result;
   * the counters only feed consolidation usage signals and /memory-insights.
   */
  usageHitTrackingEnabled?: boolean;
  /**
   * Feed recorded memory_search recalls into consolidation prompts as per-entry
   * "Usage Signals" (the blog-style promotion gate: well-recalled entries are
   * load-bearing, never-recalled entries are weaker keep candidates). Inert
   * until entries have actually been recalled — fresh installs see byte-identical
   * prompts until real usage accrues. Default: true.
   */
  consolidationUsageSignals?: boolean;
  /** Log failed auto-consolidation attempts to the session console. Default: true */
  autoConsolidationWarnOnFailure: boolean;
  /** Inject pinned STANDING.md instructions into every session. Default: true */
  standingInstructionsEnabled: boolean;
  /**
   * Session retention window in days. A positive value opts in to pruning
   * sessions (and their messages) older than the window on startup; `0`/omitted
   * disables pruning so no existing searchable history is silently deleted.
   * Default: 0 (disabled).
   */
  sessionRetentionDays?: number;
}

export type MemoryCategory =
  | "failure"
  | "correction"
  | "insight"
  | "preference"
  | "convention"
  | "tool-quirk";

export interface MemoryResult {
  success: boolean;
  error?: string;
  message?: string;
  warning?: string;
  warnings?: string[];
  target?: "memory" | "user" | "failure" | "project";
  entries?: string[];
  usage?: string;
  entry_count?: number;
  evicted_entries?: string[];
  evicted_count?: number;
  matches?: string[];
  /** Targets that contain old_text when a replace/remove was sent to the wrong one. */
  matching_targets?: Array<"memory" | "user" | "failure" | "project">;
}

export interface MemoryMutationOperation {
  action: "add" | "replace" | "remove";
  content?: string;
  oldText?: string;
  category?: MemoryCategory;
  failureReason?: string;
  project?: string;
}

export interface MemorySnapshot {
  memory: string;
  user: string;
}

export interface ConsolidationResult {
  /** Whether consolidation succeeded */
  consolidated: boolean;
  /** Error message if consolidation failed */
  error?: string;
  /**
   * True when at least one round completed but the run ended with a failure
   * or the store is still over its capacity goal. Progress is real and on
   * disk; retriggering continues from current state. Consumers should
   * surface `error` alongside the success path when this is set.
   */
  partial?: boolean;
  /**
   * Number of subprocess consolidation rounds that completed successfully
   * (chunked path only; absent for single-shot runs).
   */
  rounds?: number;
  /**
   * Set when another session already holds the consolidation lock for this
   * target. Nothing is broken — the work is happening elsewhere — so callers
   * should tell the user to retry rather than report a failed consolidation.
   */
  deferred?: boolean;
}

export type SkillScope = "global" | "project";

export interface SkillIndex {
  /** Stable id for read/update/delete operations */
  skillId: string;
  /** Whether the skill is global or project-scoped */
  scope: SkillScope;
  /** File name on disk (usually SKILL.md) */
  fileName: string;
  /** Absolute path to the skill file */
  path: string;
  /** Active project name for project-scoped skills */
  projectName?: string;
  /** Pi skill slug stored in frontmatter and folder name */
  name: string;
  /** Optional human-friendly title preserved for UI output */
  displayName?: string;
  /** Short description shown in skill listings */
  description: string;
  /** ISO date created */
  created: string;
  /** ISO date last updated */
  updated: string;
}

export interface SkillDocument extends SkillIndex {
  /** Full markdown body (after frontmatter) */
  body: string;
  /** Version number */
  version: number;
}

export interface SkillResult {
  success: boolean;
  error?: string;
  message?: string;
  fileName?: string;
  skillId?: string;
  scope?: SkillScope;
  path?: string;
  conflictType?: "duplicate" | "similar" | "name-collision" | "scope-conflict";
  similarSkillIds?: string[];
  suggestedAction?: "patch" | "update" | "rename";
}

/**
 * Extract displayable text from a Pi session entry message.
 *
 * Accepts any value — returns null for non-message entries (BashExecutionMessage,
 * NotificationMessage, etc.) that lack a `content` property.
 *
 * Returns the concatenated text, truncated to `maxLength` chars.
 */
export function getMessageText(msg: unknown, maxLength = 500): string | null {
  if (typeof msg !== "object" || msg === null) return null;
  const { role, content } = msg as Record<string, unknown>;
  if (typeof role !== "string") return null;

  if (typeof content === "string") {
    return content.slice(0, maxLength);
  }
  if (Array.isArray(content)) {
    const text = (content as TextContent[])
      .filter((block): block is TextContent => block.type === "text" && typeof block.text === "string")
      .map((block) => block.text)
      .join("\n");
    return text.length > 0 ? text.slice(0, maxLength) : null;
  }
  return null;
}
